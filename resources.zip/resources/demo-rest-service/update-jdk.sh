#!/usr/bin/env bash

# Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0

sudo yum install java-1.8.0 -y
sudo yum remove java-1.7.0-openjdk -y

#!/usr/bin/env bash
set -e
echo "send 100 place order request"
for i in {1..100}
do
   curl "localhost:8080/ordering?name=item${i}&amount=${i}"
   echo ""
   sleep 1
done